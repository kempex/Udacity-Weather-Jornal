/* Global Variables */
console.log('start')

document.getElementById('generate').addEventListener('click', xretrive);
// new date object dynamically with JS
let myd = new Date();
let date2 = myd.toLocaleString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });




// Perform Async GET from openweather api
const baseURL = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const apikey = '2b4eacdc7943449a504e905a8ecc9e3b';
const retriveTemperature = async (baseURL, code,  apikey)=>{

    const response = await fetch(baseURL + code + ',us' + '&APPID=' +  apikey)
    console.log(response);
    try {
        const data = await response.json();
        console.log(data);
        return data;
    }
    catch(error) {
        console.log('error', error);
    }
}

function xretrive(e){
    const zip = document.getElementById('zip').value;
    const myfeelings = document.getElementById('feelings').value;
    retriveTemperature(baseURL, zip,  apikey)
    .then(function (data){
        postData('http://localhost:8200/station_data', {temperature: data.main.temp, date: date2, myfeelings: myfeelings } )
        // Function which refresh User Iinterface
        .then(function() {
            refreshUI()
        })
    })
}
// Update user interface
const refreshUI = async () => {
    const request = await fetch('http://localhost:8200/all');
    try {
        const mm = await request.json();
       
        document.getElementById('temp').innerHTML = mm.temperature;
        document.getElementById('date').innerHTML = mm.date;
        document.getElementById('content').innerHTML = mm.myfeelings;
    }
    catch (error) {
        console.log('error', error);
    }
}
// Async POST
const postData = async (url = '', data = {}) => {
    const postRequest = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    });
    try {
        const newData = await postRequest.json();
        //api json response
        console.log(newData);
        return newData;
    }
    catch (error) {
        console.log('Error', error);
    }
}

