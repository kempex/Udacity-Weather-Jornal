const text ='i love my wife'// document.getElementById("test-statement").value;

console.log(text);
fetch("http://localhost:8009/api", {
  method: "POST",
  mode: "cors",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({ text })
})
.then(res => res.json())
.then(function(res) {
  
      alert(res.polarity)
    });